package com.docusign.core.model.manifestModels;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LinkToAPIMethods {
    public String Path;

    public String PathName;
}
