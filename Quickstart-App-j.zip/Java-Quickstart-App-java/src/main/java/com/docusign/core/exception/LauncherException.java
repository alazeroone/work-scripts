package com.docusign.core.exception;

public class LauncherException extends Exception {

    private static final long serialVersionUID = -609744571799853289L;

    public LauncherException(String message) {
        super(message);
    }
}
