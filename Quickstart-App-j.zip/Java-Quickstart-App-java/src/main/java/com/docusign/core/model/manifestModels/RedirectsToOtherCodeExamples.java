package com.docusign.core.model.manifestModels;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RedirectsToOtherCodeExamples {
    public Integer CodeExampleToRedirectTo;

    public String RedirectText;
}
